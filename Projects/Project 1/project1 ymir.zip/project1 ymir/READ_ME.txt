# Project 1

Process and resource manager.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.


### Installing

All you need is a python 3 installation. 


### Using program

The program can read files and gives an output in the same folder. To run open manager using python 3.
When starting program, it is possible to enter user input mode or read file mode.

In read file mode, all inputs must be written correct and formatted one input on each line.


### Included in zip

You will get a file named program.py, manager.py (run this), READ_ME.txt (this file).