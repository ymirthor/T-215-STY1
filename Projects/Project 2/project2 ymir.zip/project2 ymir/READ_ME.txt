TO EXECUTE PROGRAM, just run the program.py, with python 3.7+

OUTPUT is located in output.txt
line 1 of output is no-dp
line 2 of output is dp